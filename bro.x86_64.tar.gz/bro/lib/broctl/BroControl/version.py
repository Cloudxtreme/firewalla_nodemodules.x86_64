#
# Settings that specify the version of BroControl
#

VERSION = "1.4"
BROBASE = "/usr/local/bro"
CFGFILE = "/usr/local/bro/etc/broctl.cfg"
BROSCRIPTDIR = "/usr/local/bro/share/bro"
